package shay.com.gpanoti;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Mohamad Idzhar on 9/28/2017.
 */

public class CheckNetwork {
        private AppCompatActivity activity;

        public CheckNetwork(AppCompatActivity a) {
            this.activity = a;
        }

        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager = (ConnectivityManager) activity
                    .getSystemService(AppCompatActivity.CONNECTIVITY_SERVICE);

            NetworkInfo nInfo = connectivityManager.getActiveNetworkInfo();
            if (nInfo != null && nInfo.isConnectedOrConnecting()) {
                return true;
            }
            return false;
        }
}
