package shay.com.gpanoti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.util.HashMap;

public class MenuActivity extends AppCompatActivity {
    SessionManager session;
    public Button btnShowToken2;
    TextView nametv,matrictv;
    Intent i;
    String token;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        getSupportActionBar().hide();
        btnShowToken2 = findViewById(R.id.btnShowToken2);
        session = new SessionManager(getApplicationContext());
        token = FirebaseInstanceId.getInstance().getToken();
        nametv = findViewById(R.id.tvName);
        matrictv = findViewById(R.id.tvMatric);

        HashMap<String, String> user = session.getUserDetails();
        String name = user.get(SessionManager.KEY_NAME);
        String matric = user.get(SessionManager.KEY_MATRIC);

        nametv.setText(name);
        matrictv.setText(matric);
        boolean status = session.checkLogin();

        if(!status){
            i = new Intent(MenuActivity.this, MainActivity.class);
        }

        btnShowToken2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MenuActivity.this, "Token-- "+token, Toast.LENGTH_LONG).show();
                Log.d("Token", token);
            }
        });
    }
}
