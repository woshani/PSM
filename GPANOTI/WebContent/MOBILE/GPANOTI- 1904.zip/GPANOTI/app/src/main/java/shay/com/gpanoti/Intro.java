package shay.com.gpanoti;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Intro extends AppCompatActivity {
    private static int TIME_OUT = 3000;
    SessionManager session;
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro2);
        getSupportActionBar().hide();
        session = new SessionManager(getApplicationContext());

        boolean status = session.checkLogin();
        if(status){
            i = new Intent(Intro.this, MenuActivity.class);
        }else{
            i = new Intent(Intro.this, MainActivity.class);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(i);
                finish();
            }
        }, TIME_OUT);
    }
}
