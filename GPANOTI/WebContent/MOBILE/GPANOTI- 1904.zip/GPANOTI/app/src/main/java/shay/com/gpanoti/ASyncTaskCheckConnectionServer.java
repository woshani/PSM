package shay.com.gpanoti;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Admin on 9/28/2017.
 */

public class ASyncTaskCheckConnectionServer extends AsyncTask<String, String, String> {

    //private ProgressDialog pDialog;

    public AppCompatActivity activity;

    public ASyncTaskCheckConnectionServer(AppCompatActivity a) {
        this.activity = a;
    }

    @Override
    protected void onPreExecute() {
        //pDialog = new ProgressDialog(this.activity);
        //pDialog.setMessage("Loading...");
        //pDialog.setCancelable(false);
        //pDialog.show();
        //super.onPreExecute();
        Toast.makeText(this.activity, "Checking server status..", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected String doInBackground(String... arg0) {
        String result = "0";


        if (new CheckNetwork(this.activity).isNetworkAvailable()) {

            try {
                URL mUrl = new URL("http://10.0.2.2:8080/GPANOTI/");

                HttpURLConnection httpConnection = (HttpURLConnection) mUrl.openConnection();
                httpConnection.setRequestMethod("POST");
                httpConnection.setRequestProperty("Content-length", "0");
                httpConnection.setUseCaches(false);
                httpConnection.setAllowUserInteraction(false);
                httpConnection.setConnectTimeout(3000);
                httpConnection.setReadTimeout(50000);

                httpConnection.connect();

                int responseCode = httpConnection.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    br.close();
                    //return sb.toString();
                    //Log.d("RESULT URL PRIM : ",sb.toString());
                    return "200";
                }
            } catch (IOException e) {
                //e.printStackTrace();
                return "404";
            } catch (Exception ex) {
                //ex.printStackTrace();
                return "404";
            }
        }
        return result;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        //if (pDialog.isShowing()) {
        //    pDialog.dismiss();
        //}
    }


}
