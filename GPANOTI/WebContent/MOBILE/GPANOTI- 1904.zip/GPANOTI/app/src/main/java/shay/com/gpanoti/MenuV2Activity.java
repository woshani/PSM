package shay.com.gpanoti;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class MenuV2Activity extends AppCompatActivity
        implements
        Home.OnFragmentInteractionListener,
        MessageFragment.OnFragmentInteractionListener,
        ChangePassword.OnFragmentInteractionListener,
        NavigationView.OnNavigationItemSelectedListener {



    SessionManager session;
    TextView nametv2,matrictv2;
    HashMap<String, String> user;
    boolean logoutStat;
    String host = Connection.getHost();
    String token;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_v2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        View decorView = getWindow().getDecorView();
        // Hide the status bar.
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);



        session = new SessionManager(getApplicationContext());
        boolean status = session.checkLogin();
        if(!status){
            Intent i = new Intent(MenuV2Activity.this, MainActivity.class);
            startActivity(i);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        String extras = getIntent().getStringExtra("ACTION");
        if(extras.equalsIgnoreCase("PUSHNOTI")){
            //NOTE:  Checks first item in the navigation drawer initially
            navigationView.setCheckedItem(R.id.nav_message);

            //NOTE:  Open home initially.
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, new MessageFragment());
            ft.commit();
            getSupportActionBar().setTitle("Message");
        }else{
            //NOTE:  Checks first item in the navigation drawer initially
            navigationView.setCheckedItem(R.id.nav_frag1);

            //NOTE:  Open home initially.
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, new Home());
            ft.commit();
            getSupportActionBar().setTitle("Home");
        }


        View navHeaderView = navigationView.inflateHeaderView(R.layout.nav_header_menu_v2);
        //setting name in android nav drawer
        nametv2 = navHeaderView.findViewById(R.id.tvNameV2);
        matrictv2 = navHeaderView.findViewById(R.id.tvMatricV2);

        user = session.getUserDetails();
        token = FirebaseInstanceId.getInstance().getToken();
        if(user != null) {
            String name = user.get(SessionManager.KEY_NAME);
            String matric = user.get(SessionManager.KEY_MATRIC);
            Log.d("name",name);
            nametv2.setText(name);
            matrictv2.setText(matric);
        }

        //for changepassword/////////////////////////////////////////////////////////////////////////


    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_v2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        //NOTE: creating fragment object
        Fragment fragment = null;
        if (id == R.id.nav_frag1) {
            fragment = new Home();
            getSupportActionBar().setTitle("Home");
        }else if(id == R.id.nav_logout){
            HashMap data = new HashMap();
            data.put("matric",user.get(SessionManager.KEY_MATRIC));
            PostResponseAsyncTask logout = new PostResponseAsyncTask(MenuV2Activity.this, data, new AsyncResponse() {
                @Override
                public void processFinish(String s) {

                    try {
                        JSONObject obj = new JSONObject(s);
                        Log.d("LOGOUT",obj.get("res").toString());
                        if (obj.get("res").equals("OK")){
                            logoutStat = session.logoutUser();
                            if(logoutStat == true){
                                finish();
//                                Intent i = new Intent(MenuV2Activity.this, MainActivity.class);
////                                    // Closing all the Activities
////                                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
////
////                                    // Add new Flag to start new Activity
////                                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//
//                                // Staring Login Activity
//                                MenuV2Activity.this.startActivity(i);
                            }
                        }else{
                            Toast.makeText(MenuV2Activity.this, "Something was wrong during logging out,try again later", Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            logout.execute(host+"LogoutMobile");
        }else if(id == R.id.nav_token){
            Toast.makeText(MenuV2Activity.this, token, Toast.LENGTH_LONG).show();
        }else if(id == R.id.nav_message){
            fragment = new MessageFragment();
            getSupportActionBar().setTitle("Message");
        }else if(id == R.id.nav_change_pass){
            fragment = new ChangePassword();
            getSupportActionBar().setTitle("Change Password");
        }

        //NOTE: Fragment changing code
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.mainFrame, fragment);
            ft.commit();
        }

        //NOTE:  Closing the drawer after selecting
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout); //Ya you can also globalize this variable :P
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
