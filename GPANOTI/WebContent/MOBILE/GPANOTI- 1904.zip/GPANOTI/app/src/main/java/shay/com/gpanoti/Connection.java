package shay.com.gpanoti;

/**
 * Created by wosha on 17/12/2017.
 */

public class Connection {
    public static String getHost() {
        return host;
    }

    private static String host = "http://192.168.0.138:8080/GPANOTI/";
    //private static String host = " https://bb97ca2b.ngrok.io/GPANOTI/";
}
