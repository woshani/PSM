package shay.com.gpanoti;

/**
 * Created by wosha on 17/12/2017.
 */

public class Connection {
    public static String getHost() {
        return host;
    }

    private static String host = "http://192.168.0.177:8080/GPANOTI/";
}
