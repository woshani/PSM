package shay.com.gpanoti;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PermissionActivity extends AppCompatActivity {

    //Firebase Notification TAG
    private static final String TAG = "MainActivity";

       @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        //permissionStatus = getSharedPreferences("permissionStatus", MODE_PRIVATE);

        boolean statusNotificationPermission = NotificationManagerCompat.from(PermissionActivity.this).areNotificationsEnabled();

        Button btnSetting = (Button) findViewById(R.id.btnSetting);

        if(!statusNotificationPermission) {
            btnSetting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //android debug log message
                    Log.d(TAG, "Token : " + "Demo");

                    //Show instant message on android
                    Toast.makeText(PermissionActivity.this, "Sila buka akses Notifikasi untuk PRIM", Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + BuildConfig.APPLICATION_ID)));

                    if (!NotificationManagerCompat.from(PermissionActivity.this).areNotificationsEnabled()) {
                        Toast.makeText(PermissionActivity.this, "PRIM memerlukan akses kepada Notifikasi untuk beroperasi dengan sempurna", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(PermissionActivity.this, "Akses notifikasi telah diberikan.", Toast.LENGTH_SHORT).show();
                        onBackPressed();
                    }
                }
            });


        }
    }

}
