package shay.com.gpanoti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    public Button btnShowToken,login;
    public EditText matric,password;
    SessionManager session;
    String host = Connection.getHost();
    String token;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        session = new SessionManager(getApplicationContext());
        btnShowToken = findViewById(R.id.btnShowToken);
        login = findViewById(R.id.btnLogin);
        matric = findViewById(R.id.etMatric);
        password = findViewById(R.id.etPass);

        token = FirebaseInstanceId.getInstance().getToken();

        btnShowToken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Token-- "+token, Toast.LENGTH_LONG).show();
                Log.d("Token", token);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String matricNo = matric.getText().toString();
                String passwordStr = password.getText().toString();

                // Check if username, password is filled
                if(matricNo.trim().length() > 0 && passwordStr.trim().length() > 0){
                    HashMap postData = new HashMap();
                    postData.put("matric",matricNo);
                    postData.put("password",passwordStr);
                    postData.put("device",token);
                    PostResponseAsyncTask loginTask = new PostResponseAsyncTask(MainActivity.this, postData, new AsyncResponse() {
                        @Override
                        public void processFinish(String result) {
                            Log.d("Login",result.toString());
                            try {
                                JSONObject obj = new JSONObject(result);
                                if(obj.get("status").equals("false")){
                                    Toast.makeText(MainActivity.this, "Matric number/Password incorrect or User does not exist", Toast.LENGTH_LONG).show();
                                }else if(obj.get("status").equals("true")){
                                    session.createLoginSession(obj.get("name").toString(), matric.getText().toString());
                                    // Staring MainActivity
                                    Intent i = new Intent(getApplicationContext(), MenuActivity.class);
                                    startActivity(i);
                                    finish();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });
                    loginTask.execute(host+"LoginMobile");
                }
            }
        });

    }
}
