package shay.com.gpanoti;

/**
 * Created by wosha on 17/12/2017.
 */

public class Connection {
    public static String getHost() {
        return host;
    }

    private static String host = "http://192.168.0.2:8080/GPANOTI/";
    //THIS FOR PUBLIC IP WITH PORT FORWARDING
    //private static String host = "http:42.188.53.82:9999/GPANOTI/";
    //private static String host = "https://79f201b2.ngrok.io/GPANOTI/";
}
