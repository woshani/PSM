package shay.com.gpanoti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class MenuActivity extends AppCompatActivity {
    SessionManager session;
    public Button btnShowToken2,btnout;
    TextView nametv,matrictv;
    Intent i;
    String token;
    String host = Connection.getHost();
    boolean logoutStat;
    HashMap<String, String> user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        getSupportActionBar().hide();
        btnShowToken2 = findViewById(R.id.btnShowToken2);
        session = new SessionManager(getApplicationContext());
        token = FirebaseInstanceId.getInstance().getToken();
        nametv = findViewById(R.id.tvName);
        matrictv = findViewById(R.id.tvMatric);
        btnout = findViewById(R.id.btnOut);
        user = session.getUserDetails();
        String name = user.get(SessionManager.KEY_NAME);
        String matric = user.get(SessionManager.KEY_MATRIC);

        nametv.setText(name);
        matrictv.setText(matric);
        boolean status = session.checkLogin();

        if(!status){
            i = new Intent(MenuActivity.this, MainActivity.class);
        }

        btnShowToken2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MenuActivity.this, "Token-- "+token, Toast.LENGTH_LONG).show();
                Log.d("Token", token);
            }
        });

        btnout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                HashMap data = new HashMap();
                data.put("matric",user.get(SessionManager.KEY_MATRIC));
                PostResponseAsyncTask logout = new PostResponseAsyncTask(MenuActivity.this, data, new AsyncResponse() {
                    @Override
                    public void processFinish(String s) {

                        try {
                            JSONObject obj = new JSONObject(s);
                            Log.d("LOGOUT",obj.get("res").toString());
                            if (obj.get("res").equals("OK")){
                                logoutStat = session.logoutUser();
                                if(logoutStat == true){
                                    Intent i = new Intent(MenuActivity.this, MainActivity.class);
//                                    // Closing all the Activities
//                                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//
//                                    // Add new Flag to start new Activity
//                                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                                // Staring Login Activity
                                    MenuActivity.this.startActivity(i);
                                }
                            }else{
                                Toast.makeText(MenuActivity.this, "Something was wrong during logging out,try again later", Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
                logout.execute(host+"LogoutMobile");
            }
        });
    }
}
