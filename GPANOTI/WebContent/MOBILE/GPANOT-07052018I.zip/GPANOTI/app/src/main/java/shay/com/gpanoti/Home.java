package shay.com.gpanoti;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.EachExceptionsHandler;
import com.kosalgeek.genasync12.PostResponseAsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Home.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Home#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Home extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    View v;
    TextView gpahome,sesihome;
    SessionManager session;
    String host = Connection.getHost();
    LineChart chart;
    List<Entry> entries;
    String[] quarters;

    private OnFragmentInteractionListener mListener;

    public Home() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment home.
     */
    // TODO: Rename and change types and number of parameters
    public static Home newInstance(String param1, String param2) {
        Home fragment = new Home();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v =  inflater.inflate(R.layout.fragment_home, container, false);
        gpahome = v.findViewById(R.id.tvgpahome);
        sesihome = v.findViewById(R.id.tvsesihome);
        session = new SessionManager(v.getContext());

        chart = v.findViewById(R.id.chartViewer);
        entries = new ArrayList<Entry>();
        HashMap<String,String> user = session.getUserDetails();
        HashMap postdata = new HashMap();
        postdata.put("matric",user.get(SessionManager.KEY_MATRIC));
        PostResponseAsyncTask gpa = new PostResponseAsyncTask(v.getContext(), postdata, new AsyncResponse() {
            @Override
            public void processFinish(String s) {
                try {
                    JSONObject obj = new JSONObject(s);
                    if(obj.get("status").toString().equals("true")){
                        gpahome.setText(obj.get("gpa").toString());
                        String sss = "<b>"+obj.get("sesi").toString()+"</b>";
                        sesihome.setText("GPA for semester/session "+ Html.fromHtml(sss));
                    }else{
                        gpahome.setText("N/A");
                        sesihome.setText("N/A");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        gpa.execute(host+"GetCurrentGpaServ");
        gpa.setEachExceptionsHandler(new EachExceptionsHandler() {
            @Override
            public void handleIOException(IOException e) {
                Toast.makeText(v.getContext(), "Error with internet or web server.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void handleMalformedURLException(MalformedURLException e) {
                Toast.makeText(v.getContext(), "Error with the URL.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void handleProtocolException(ProtocolException e) {
                Toast.makeText(v.getContext(), "Error with protocol.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void handleUnsupportedEncodingException(UnsupportedEncodingException e) {
                Toast.makeText(v.getContext(), "Error with text encoding.", Toast.LENGTH_LONG).show();
            }
        });

        HashMap matrik = new HashMap();
        matrik.put("matric",user.get(SessionManager.KEY_MATRIC));
        PostResponseAsyncTask getGraph = new PostResponseAsyncTask(v.getContext(), matrik, new AsyncResponse() {
            @Override
            public void processFinish(String s) {
                Log.d("getGraph",s);
                try {

                    JSONArray js =  new JSONArray(s);
                    quarters = new String[js.length()];
                    Log.d("js size",String.valueOf(js.length()));
                    for(int i=0;i<js.length();i++){
                        quarters[i] = js.getJSONObject(i).getString("session");
                        entries.add(new Entry(i,Float.valueOf(js.getJSONObject(i).getString("gpa"))));
                        Log.d("quaters",quarters[i]);
                    }

                    LineDataSet data = new LineDataSet(entries,"GPA for previous semester");
                    XAxis xAxis = chart.getXAxis();
                    xAxis.setValueFormatter(new MyXAxisValueFormatter(quarters));
                    xAxis.setGranularity(1f); // minimum axis-step (interval) is 1
                    xAxis.setAxisMinimum((float)0);
                    LineData lineData = new LineData(data);
                    chart.setData(lineData);
                    chart.getDescription().setEnabled(false);
                    chart.invalidate();
                    chart.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        getGraph.execute(host+"GetResultAllSem");
        getGraph.setEachExceptionsHandler(new EachExceptionsHandler() {
            @Override
            public void handleIOException(IOException e) {
                Toast.makeText(v.getContext(), "Error with internet or web server.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void handleMalformedURLException(MalformedURLException e) {
                Toast.makeText(v.getContext(), "Error with the URL.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void handleProtocolException(ProtocolException e) {
                Toast.makeText(v.getContext(), "Error with protocol.", Toast.LENGTH_LONG).show();
            }

            @Override
            public void handleUnsupportedEncodingException(UnsupportedEncodingException e) {
                Toast.makeText(v.getContext(), "Error with text encoding.", Toast.LENGTH_LONG).show();
            }
        });

        return v;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
