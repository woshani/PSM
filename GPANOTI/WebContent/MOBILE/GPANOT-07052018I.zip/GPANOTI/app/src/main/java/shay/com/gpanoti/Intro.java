package shay.com.gpanoti;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Intro extends AppCompatActivity {
    private static int TIME_OUT = 3000;
    SessionManager session;
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro2);
        View decorView = getWindow().getDecorView();
        // Hide the status bar.
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        getSupportActionBar().hide();
        session = new SessionManager(getApplicationContext());


        boolean status = session.checkLogin();
        if(status){
            i = new Intent(Intro.this, MenuV2Activity.class);
            i.putExtra("ACTION", "INTRO");
        }else{
            i = new Intent(Intro.this, MainActivity.class);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(i);
                finish();
            }
        }, TIME_OUT);
    }
}
